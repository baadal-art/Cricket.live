# CricZone Live

Create a modern, attractive and responsive cricket information website called "CricZone" using HTML, CSS and JavaScript.



The website should look like a genuine college student project: clean, modern and functional, but not overly advanced.



Main Pages



1. Home

   

   - Website logo/name: CricZone

   - Navigation: Home, Live Scores, Matches, Teams, Players, Rankings, About

   - Cricket-themed hero section

   - Live Matches

   - Recent Matches

   - Upcoming Matches



2. Live Scores

   

   - Live/in-progress match cards

   - Teams, scores, overs, run rate and match status

   - Use realistic sample/demo data

   - If no API is connected, clearly show "Demo/Static Data"



3. Matches

   

   - Upcoming and completed matches

   - Date, venue, teams and result

   - Filters for Test, ODI and T20



4. Teams

   

   - Team cards with logo placeholders

   - Popular international cricket teams



5. Players

   

   - Player cards with photo placeholders

   - Name, country, role and basic statistics



6. Rankings

   

   - Tabs for Teams, Batsmen and Bowlers

   - Ranking, name, rating and country



7. About

   

   - Explain that CricZone is a student-created cricket information project

   - Add a simple contact/feedback section



Creator/Credits



Add a professional "Project Credits" section on the About page and a small credit in the website footer:



Created by: Baadal Gupta

Computer Engineering – 5th Semester



Do not make the credit section overly large. Keep it clean and professional.



Design



- Modern cricket/sports-inspired design

- Responsive on mobile, tablet and desktop

- Attractive cards with hover effects

- Modern typography

- Cricket-related icons

- Consistent professional color palette

- Clean footer



JavaScript Features



- Match format filtering

- Search players and teams

- Interactive score cards

- Match details popup/modal

- Responsive mobile navigation

- Basic page interactions



Files



Create:



- index.html

- scores.html

- matches.html

- teams.html

- players.html

- rankings.html

- about.html

- style.css

- script.js



Keep the code beginner-friendly, properly organized and easy to explain in a college viva. Make it visually impressive but realistic for a Computer Engineering 5th-semester student project.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://criczonee.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/780bb60d-c2a9-43f2-91ec-1afbe5390cb8).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
