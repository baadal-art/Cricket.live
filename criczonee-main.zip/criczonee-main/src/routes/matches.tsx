import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "../components/criczone-layout";
import { MatchCard } from "../components/match-card";
import { matches } from "../lib/cricket-data";

export const Route = createFileRoute("/matches")({
  head: () => ({ meta: [{ title: "Cricket Match Schedule — CricZone" }, { name: "description", content: "Browse upcoming and completed Test, ODI and T20 cricket matches." }, { property: "og:title", content: "Cricket Match Schedule — CricZone" }, { property: "og:description", content: "Filter cricket fixtures and results by match format." }] }), component: MatchesPage,
});
function MatchesPage() { const [format, setFormat] = useState("All"); const shown = format === "All" ? matches : matches.filter((m) => m.format === format); return <><PageHeader eyebrow="Fixtures & results" title="Matches" copy="Browse upcoming fixtures and completed results across every major format." /><section className="page-shell"><div className="mb-6 flex flex-wrap gap-2" aria-label="Filter by format">{["All", "Test", "ODI", "T20"].map((item) => <button key={item} onClick={() => setFormat(item)} className={`filter-button ${format === item ? "filter-button-active" : ""}`}>{item}</button>)}</div><div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{shown.map((match) => <MatchCard key={match.id} match={match} />)}</div></section></>; }