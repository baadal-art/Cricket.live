import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarDays, Radio, Trophy } from "lucide-react";
import { matches } from "../lib/cricket-data";
import { DemoBadge } from "../components/criczone-layout";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "CricZone — Cricket Scores, Matches & Rankings" },
    { name: "description", content: "Explore live cricket scores, match schedules, teams, players and rankings on CricZone." },
    { property: "og:title", content: "CricZone — Cricket Scores, Matches & Rankings" },
    { property: "og:description", content: "Your student-built cricket information hub for scores, matches and rankings." },
  ] }),
  component: HomePage,
});

function MiniMatch({ match }: { match: (typeof matches)[number] }) {
  return (
    <article className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b-2 border-foreground/10 px-4 py-4 last:border-b-0">
      <div className="min-w-0">
        <p className="truncate text-sm font-semibold">{match.team1} vs {match.team2}</p>
        <p className="mt-1 truncate font-mono text-[10px] text-muted-foreground">{match.format} · {match.venue} · {match.date}</p>
      </div>
      <span className="shrink-0 rounded border-2 border-primary/40 px-2 py-1 font-mono text-[10px] font-semibold text-primary">{match.result ?? "VS"}</span>
    </article>
  );
}

function HomePage() {
  const live = matches[0];
  return (
    <>
      <section className="border-b-2 border-foreground bg-secondary">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-[.85fr_1.15fr] md:items-center md:py-16">
          <div>
            <DemoBadge />
            <h1 className="mt-5 font-display text-5xl uppercase leading-[.98] sm:text-7xl">Every run.<br /><span className="text-primary">Every wicket.</span></h1>
            <p className="mt-5 max-w-lg text-base leading-7 text-muted-foreground">Your clean, quick cricket desk for live scores, schedules, teams, players and world rankings.</p>
            <Link to="/scores" className="action-button mt-6">Follow live scores <ArrowRight size={16} /></Link>
          </div>
          {live && <div className="score-card bg-background">
            <div className="flex items-center justify-between bg-foreground px-4 py-3 text-background">
              <span className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-widest"><span className="live-pulse size-2 rounded-full bg-live" /> Live · Match 7</span>
              <span className="font-mono text-xs">{live.format}</span>
            </div>
            <div className="space-y-4 p-5">
              {[{ name: live.team1, score: live.score1, code: "IND" }, { name: live.team2, score: live.score2, code: "AUS" }].map((team) => (
                <div key={team.name} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
                  <div className="flex min-w-0 items-center gap-3"><span className="grid size-10 shrink-0 place-items-center rounded-full border-2 border-foreground font-mono text-xs font-bold">{team.code}</span><span className="truncate font-semibold">{team.name}</span></div>
                  <strong className="font-mono text-xl">{team.score}</strong>
                </div>
              ))}
              <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3 border-t-2 border-foreground/10 pt-3 font-mono text-xs"><span>Overs {live.overs}</span><span className="text-right font-semibold text-primary">{live.status}</span></div>
            </div>
            <div className="flex items-center justify-between border-t-2 border-foreground bg-accent/15 px-4 py-3 font-mono text-xs"><span className="text-muted-foreground">Run rate</span><strong>{live.runRate}</strong></div>
          </div>}
        </div>
      </section>
      <section className="page-shell">
        <div className="grid gap-8 lg:grid-cols-2">
          <div><div className="mb-3 flex items-center justify-between"><h2 className="section-title flex items-center gap-2"><Trophy size={20} /> Recent matches</h2><Link to="/matches" className="font-mono text-xs text-primary">View all</Link></div><div className="score-card">{matches.filter((m) => m.result).slice(0, 3).map((m) => <MiniMatch key={m.id} match={m} />)}</div></div>
          <div><div className="mb-3 flex items-center justify-between"><h2 className="section-title flex items-center gap-2"><CalendarDays size={20} /> Upcoming</h2><Link to="/matches" className="font-mono text-xs text-primary">Full schedule</Link></div><div className="score-card">{matches.filter((m) => m.status === "Upcoming").map((m) => <MiniMatch key={m.id} match={m} />)}</div></div>
        </div>
        <div className="mt-10 grid gap-3 border-y-2 border-foreground py-5 sm:grid-cols-3">
          {[{ icon: Radio, value: "2", label: "Matches live" }, { icon: CalendarDays, value: "8", label: "Matches listed" }, { icon: Trophy, value: "3", label: "Formats covered" }].map((item) => <div key={item.label} className="flex items-center gap-3 px-3"><item.icon size={22} className="text-primary" /><span className="font-display text-3xl">{item.value}</span><span className="text-xs text-muted-foreground">{item.label}</span></div>)}
        </div>
      </section>
    </>
  );
}