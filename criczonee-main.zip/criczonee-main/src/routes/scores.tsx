import { createFileRoute } from "@tanstack/react-router";
import { DemoBadge, PageHeader } from "../components/criczone-layout";
import { MatchCard } from "../components/match-card";
import { matches } from "../lib/cricket-data";

export const Route = createFileRoute("/scores")({
  head: () => ({ meta: [{ title: "Live Cricket Scores — CricZone" }, { name: "description", content: "Follow in-progress cricket matches with scores, overs and run rates." }, { property: "og:title", content: "Live Cricket Scores — CricZone" }, { property: "og:description", content: "In-progress demo cricket scores with match details." }] }),
  component: ScoresPage,
});
function ScoresPage() { return <><PageHeader eyebrow="Score centre" title="Live Scores" copy="Follow every run and wicket from matches currently in progress." /><section className="page-shell"><DemoBadge /><div className="mt-5 grid gap-5 md:grid-cols-2">{matches.filter((match) => match.live).map((match) => <MatchCard key={match.id} match={match} />)}</div><p className="mt-6 border-l-4 border-amber bg-accent/10 p-4 text-sm text-muted-foreground">These scores are realistic sample data for demonstration. No live cricket API is connected.</p></section></>; }