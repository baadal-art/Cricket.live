import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X, CircleDot, Trophy, Users, UserRound, Info, CalendarDays, Radio } from "lucide-react";
import { useState, type ReactNode } from "react";

const navItems = [
  { to: "/", label: "Home", icon: CircleDot },
  { to: "/scores", label: "Live Scores", icon: Radio },
  { to: "/matches", label: "Matches", icon: CalendarDays },
  { to: "/teams", label: "Teams", icon: Users },
  { to: "/players", label: "Players", icon: UserRound },
  { to: "/rankings", label: "Rankings", icon: Trophy },
  { to: "/about", label: "About", icon: Info },
] as const;

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5" aria-label="CricZone home">
      <span className={`${compact ? "size-6" : "size-8"} grid shrink-0 place-items-center rounded-full border-2 border-foreground bg-primary`}>
        <span className="size-1.5 rounded-full bg-primary-foreground" />
      </span>
      <span className={`${compact ? "text-lg" : "text-2xl"} font-display uppercase`}>CricZone</span>
    </Link>
  );
}

export function SiteLayout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 border-b-2 border-foreground bg-background">
        <div className="mx-auto grid h-16 max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 sm:px-6">
          <Brand />
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Main navigation">
            {navItems.map((item) => (
              <Link key={item.to} to={item.to} className={`nav-link ${pathname === item.to ? "nav-link-active" : ""}`}>{item.label}</Link>
            ))}
          </nav>
          <div className="flex items-center gap-2 lg:hidden">
            <span className="demo-badge">Demo data</span>
            <button className="icon-button" onClick={() => setOpen((value) => !value)} aria-label="Toggle menu" aria-expanded={open}>
              {open ? <X size={19} /> : <Menu size={19} />}
            </button>
          </div>
        </div>
        {open && (
          <nav className="border-t-2 border-foreground bg-background px-4 py-3 lg:hidden" aria-label="Mobile navigation">
            <div className="mx-auto grid max-w-7xl grid-cols-2 gap-2">
              {navItems.map((item) => (
                <Link key={item.to} to={item.to} onClick={() => setOpen(false)} className={`mobile-link ${pathname === item.to ? "mobile-link-active" : ""}`}>
                  <item.icon size={16} className="shrink-0" /> {item.label}
                </Link>
              ))}
            </div>
          </nav>
        )}
      </header>
      <main>{children}</main>
      <footer className="border-t-2 border-foreground bg-background">
        <div className="mx-auto grid max-w-7xl gap-5 px-4 py-8 sm:grid-cols-[1fr_auto] sm:items-end sm:px-6">
          <div>
            <Brand compact />
            <p className="mt-3 max-w-xl text-sm text-muted-foreground">A student-created cricket information project. Scores shown use demo/static data.</p>
          </div>
          <p className="font-mono text-xs leading-5 sm:text-right">Created by Baadal Gupta<br /><span className="text-muted-foreground">Computer Engineering – 5th Semester</span></p>
        </div>
      </footer>
    </div>
  );
}

export function PageHeader({ eyebrow, title, copy }: { eyebrow: string; title: string; copy: string }) {
  return (
    <section className="border-b-2 border-foreground bg-secondary">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-2 max-w-4xl font-display text-5xl uppercase leading-none sm:text-7xl">{title}</h1>
        <p className="mt-4 max-w-2xl text-sm leading-6 text-muted-foreground sm:text-base">{copy}</p>
      </div>
    </section>
  );
}

export function DemoBadge() {
  return <span className="demo-badge">Demo / Static Data</span>;
}