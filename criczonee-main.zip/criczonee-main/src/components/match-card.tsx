import { MapPin, X } from "lucide-react";
import { useState } from "react";
import type { Match } from "../lib/cricket-data";

export function MatchCard({ match }: { match: Match }) {
  const [details, setDetails] = useState(false);
  return (
    <>
      <article className="score-card flex flex-col">
        <div className="flex items-center justify-between border-b-2 border-foreground bg-secondary px-4 py-2 font-mono text-[10px] uppercase tracking-widest">
          <span className="flex items-center gap-2">{match.live && <span className="live-pulse size-2 rounded-full bg-live" />}{match.status}</span><span>{match.format}</span>
        </div>
        <div className="flex-1 p-4">
          <p className="font-display text-xl uppercase">{match.team1} <span className="text-muted-foreground">vs</span> {match.team2}</p>
          <div className="mt-3 grid grid-cols-2 gap-3 font-mono text-lg font-semibold"><span>{match.score1}</span><span className="text-right">{match.score2}</span></div>
          <p className="mt-4 flex items-start gap-2 text-xs text-muted-foreground"><MapPin size={14} className="mt-0.5 shrink-0" /> {match.venue}</p>
          <p className="mt-2 font-mono text-[11px]">{match.date}</p>
          <p className="mt-3 text-sm font-semibold text-primary">{match.result ?? match.status}</p>
        </div>
        <button onClick={() => setDetails(true)} className="border-t-2 border-foreground px-4 py-3 text-left font-mono text-xs font-semibold uppercase hover:bg-secondary">View match details →</button>
      </article>
      {details && <div className="fixed inset-0 z-[70] grid place-items-center bg-foreground/65 p-4" onMouseDown={() => setDetails(false)}>
        <div className="w-full max-w-md border-2 border-foreground bg-background shadow-[7px_7px_0_var(--color-primary)]" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label="Match details">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center border-b-2 border-foreground px-5 py-4"><h2 className="min-w-0 truncate font-display text-2xl uppercase">Match details</h2><button onClick={() => setDetails(false)} className="icon-button" aria-label="Close details"><X size={18} /></button></div>
          <div className="space-y-4 p-5"><span className="demo-badge">{match.format}</span><h3 className="font-display text-3xl uppercase">{match.team1}<br /><span className="text-primary">vs {match.team2}</span></h3><div className="grid grid-cols-2 border-y-2 border-foreground py-4 font-mono text-xl font-semibold"><span>{match.score1}</span><span className="text-right">{match.score2}</span></div><p className="text-sm"><strong>Status:</strong> {match.result ?? match.status}</p><p className="text-sm"><strong>Venue:</strong> {match.venue}</p><p className="text-sm"><strong>Date:</strong> {match.date}</p>{match.runRate && <p className="font-mono text-xs text-primary">{match.runRate}</p>}</div>
        </div>
      </div>}
    </>
  );
}