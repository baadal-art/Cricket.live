export type Match = {
  id: number;
  format: "Test" | "ODI" | "T20";
  team1: string;
  team2: string;
  score1: string;
  score2: string;
  date: string;
  venue: string;
  status: string;
  result?: string;
  overs?: string;
  runRate?: string;
  live?: boolean;
};

export const matches: Match[] = [
  { id: 1, format: "T20", team1: "India", team2: "Australia", score1: "142/4", score2: "98/3", date: "Today · 19:00 IST", venue: "Wankhede Stadium, Mumbai", status: "Australia need 45 runs from 34 balls", overs: "14.2", runRate: "6.71 RRR · 5.86 CRR", live: true },
  { id: 2, format: "ODI", team1: "England", team2: "South Africa", score1: "286/7", score2: "201/5", date: "Today · 14:30 IST", venue: "The Oval, London", status: "South Africa need 86 runs from 54 balls", overs: "41.0", runRate: "9.55 RRR · 4.90 CRR", live: true },
  { id: 3, format: "ODI", team1: "India", team2: "Sri Lanka", score1: "315/6", score2: "263", date: "27 Sep 2026", venue: "R. Premadasa Stadium, Colombo", status: "Completed", result: "India won by 52 runs" },
  { id: 4, format: "Test", team1: "Pakistan", team2: "England", score1: "412 & 126/4", score2: "389", date: "24–28 Sep 2026", venue: "Gaddafi Stadium, Lahore", status: "Completed", result: "Match drawn" },
  { id: 5, format: "T20", team1: "New Zealand", team2: "South Africa", score1: "174/8", score2: "192/6", date: "22 Sep 2026", venue: "Eden Park, Auckland", status: "Completed", result: "South Africa won by 18 runs" },
  { id: 6, format: "T20", team1: "India", team2: "Bangladesh", score1: "—", score2: "—", date: "08 Oct 2026 · 19:00 IST", venue: "Arun Jaitley Stadium, Delhi", status: "Upcoming" },
  { id: 7, format: "ODI", team1: "Australia", team2: "West Indies", score1: "—", score2: "—", date: "10 Oct 2026 · 14:30 IST", venue: "MCG, Melbourne", status: "Upcoming" },
  { id: 8, format: "Test", team1: "England", team2: "New Zealand", score1: "—", score2: "—", date: "15–19 Oct 2026", venue: "Lord's, London", status: "Upcoming" },
];

export const teams = [
  { code: "IND", name: "India", board: "BCCI", color: "bg-team-blue", rank: 1 },
  { code: "AUS", name: "Australia", board: "Cricket Australia", color: "bg-team-gold", rank: 2 },
  { code: "ENG", name: "England", board: "ECB", color: "bg-team-red", rank: 3 },
  { code: "NZ", name: "New Zealand", board: "NZC", color: "bg-team-dark", rank: 4 },
  { code: "SA", name: "South Africa", board: "CSA", color: "bg-field", rank: 5 },
  { code: "PAK", name: "Pakistan", board: "PCB", color: "bg-team-green", rank: 6 },
  { code: "SL", name: "Sri Lanka", board: "SLC", color: "bg-team-navy", rank: 7 },
  { code: "WI", name: "West Indies", board: "CWI", color: "bg-team-maroon", rank: 8 },
];

export const players = [
  { initials: "VK", name: "Virat Kohli", country: "India", role: "Batsman", stat: "13,848 ODI runs" },
  { initials: "PC", name: "Pat Cummins", country: "Australia", role: "Bowler", stat: "294 Test wickets" },
  { initials: "JE", name: "Joe Root", country: "England", role: "Batsman", stat: "12,402 Test runs" },
  { initials: "KW", name: "Kane Williamson", country: "New Zealand", role: "Batsman", stat: "32 Test centuries" },
  { initials: "BR", name: "Babar Azam", country: "Pakistan", role: "Batsman", stat: "5,729 ODI runs" },
  { initials: "KR", name: "Kagiso Rabada", country: "South Africa", role: "Bowler", stat: "291 Test wickets" },
  { initials: "HS", name: "Hayley Matthews", country: "West Indies", role: "All-rounder", stat: "2,843 T20I runs" },
  { initials: "SW", name: "Sophie Ecclestone", country: "England", role: "Bowler", stat: "126 ODI wickets" },
];

export const rankings = {
  Teams: [
    ["India", "124", "IND"], ["Australia", "120", "AUS"], ["England", "112", "ENG"], ["South Africa", "109", "SA"], ["New Zealand", "103", "NZ"],
  ],
  Batsmen: [
    ["Babar Azam", "824", "PAK"], ["Rohit Sharma", "801", "IND"], ["Shubman Gill", "790", "IND"], ["Harry Brook", "775", "ENG"], ["Kane Williamson", "761", "NZ"],
  ],
  Bowlers: [
    ["Jasprit Bumrah", "836", "IND"], ["Kagiso Rabada", "818", "SA"], ["Josh Hazlewood", "802", "AUS"], ["Shaheen Afridi", "784", "PAK"], ["Adil Rashid", "776", "ENG"],
  ],
};